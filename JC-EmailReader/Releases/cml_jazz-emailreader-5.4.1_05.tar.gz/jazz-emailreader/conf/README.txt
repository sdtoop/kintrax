
       CM-Logic JazzConnect Email (Reader) Inbox Processor

This folder contains configuration files to control the Email Processor

- emailreader.xml
  Inbox configuration file

- log4j.properties
  Configures logging for the email reader

- ldap.conf
  Configures how the Email Reader interacts with LDAP

- smtp.conf
  Configures how the Email Reader interacts with SMTP

- mail.conf
  Configures how the Email Reader interacts with IMAP/POP3
  
- license.lic
  License file to enable the Email Reader to run

- jcemailreader.wrapper.conf
  YAJSW sample configuration file

