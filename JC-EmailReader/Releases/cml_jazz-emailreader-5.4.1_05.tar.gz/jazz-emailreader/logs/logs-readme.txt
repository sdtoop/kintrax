

All logs from the EmailReader as placed in this directory.


