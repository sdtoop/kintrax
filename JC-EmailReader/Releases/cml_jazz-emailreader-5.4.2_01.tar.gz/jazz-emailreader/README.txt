
       CM-Logic JazzConnect Email (Reader) Inbox Processor


The Email Reader is made up of the following directories:

- bin
  Contains top level scripts for executing the EmailReader Inbox parser

- conf
  Contains logging properties, sample yajsw config, sample LDAP config,
  license file, and the EmailReader Configuration
  - emailreader.xml
    Configure this to process the required Email Inboxes

- lib
  Contains all the required utility libraries

- jpjc-lib
  Location where the downloaded Jazz Plain Java Client library should be put

- yajsw
  Configuration/execution scripts for Yet Another Java Service Wrapper
  This enables the installation of JazzConnect-Email (Reader) as a service/daemon

- sync-rules
  Contains sample sync rules to use a base for configuring Rational Team Concert


Here are some suggested ways to run the Email Processor:

- Process the emailreader.xml Inboxes and create the corresponding WorkItems
  EmailReader.sh processEmails

- Process all the Inboxes looking up the user in LDAP
  EmailReader.sh processEmails --useldap --ldapconf jazz-emailreader/conf/ldap.conf

- Process all the Inboxes looking up the user in LDAP and creating them if they don't exist in RTC
  EmailReader.sh processEmails --useldap --ldapconf jazz-emailreader/conf/ldap.conf --usercreate

- Process all the Inboxes looking up the user in LDAP and creating them if they don't exist in RTC
  and use a template user for their email notification options
  EmailReader.sh processEmails --useldap --ldapconf jazz-emailreader/conf/ldap.conf --usercreate --tpl-email templateuser

- Process all the Inboxes every 60 seconds (forever)
  EmailReader.sh processEmails --useldap --ldapconf jazz-emailreader/conf/ldap.conf --usercreate --tpl-email templateuser --poll 60

- Process all the Inboxes and update existing WorkItems with comments (stripping previous replies)
  EmailReader.sh processEmails --useldap --ldapconf jazz-emailreader/conf/ldap.conf --usercreate --tpl-email templateuser --strip-replies

Here are some support commands:

- EmailReader.sh hostData -p -d
  Output the host data in order to request a license file

- EmailReader.sh testLisense -p -d
  Test the license to see if it's valid (for this machine)

- EmailReader.sh encodePasswd -p -d password
  Encode the supplied passwords to put into the XML configuration

- EmailReader.sh smtpTest -p -d --smtpconf jazz-emailreader/conf/smtp.conf test@cm-logic.com
  Test the specified SMTP configuration

- EmailReader.sh dumpFields -p -d --jazz-server https://rtc-server/ccm --jazz-user jazzuser --jazz-passwd passpasswd --jazz-project "Jazz Project"
  Dump the list of fields/attributes available for configuration in the Email Reader for the given project area
 