        CM-Logic JazzConnect-EmailReader

The contents of this folder are for use with the Yet Another Java Service Wrapper utility

Please follow these steps:

- Copy the complete contents from jazz-emailreader/yajsw to yajsw/bat
  cp jazz-emailreader/yajsw /path-to-yajsw/bat

- Update the wrapper config file in jazz-emailreader/conf/jcemailreader.wrapper.conf
  Search for "JazzConnect-EmailReader" to determine which fields have to be updated

- Copy this file to yajsw/conf
  cp jazz-emailreader/conf/jcemailreader.wrapper.conf /path-to-yajsw/conf


In order to test out the configuration use the following:

- Change to yajsw/bat
- Execute the console version of the wrapper
  runConsoleJcEmailReader.sh or runConsoleJcEmailReader.bat

- Make any required configuration changes


To install the daemon/service, please use the following steps:

- Install the daemon/service
  installJcEmailReaderDaemon.sh or installJcEmailReaderService.bat

- Start the daemon/service
  startJcEmailReaderDaemon.sh or startJcEmailReaderService.bat


To uninstall the daemon/service, please us the following steps:

- Stop the daemon/service
  stopJcEmailReaderDaemon.sh or stopJcEmailReaderService.bat

- Uninstall the daemon/service
  uninstallJcEmailReaderDaemon.sh or uninstallJcEmailReaderService.bat

